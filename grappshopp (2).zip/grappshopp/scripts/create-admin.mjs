// Створити (або оновити) адміністратора:
//   docker compose -f docker-compose.prod.yml exec app node scripts/create-admin.mjs you@mail.com 'ДовгийПароль123' 'Імʼя'
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { pool } from '../src/db.mjs';
const [email, pass, name = 'Адміністратор'] = process.argv.slice(2);
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '') || (pass || '').length < 10) {
  console.error("Використання: node scripts/create-admin.mjs email 'пароль (мін. 10 символів)' ['Імʼя']");
  process.exit(1);
}
await pool.query(
  `insert into users(name,email,password_hash,role) values($1,$2,$3,'admin')
   on conflict (email) do update set password_hash=excluded.password_hash, role='admin', is_active=true`,
  [name, email.toLowerCase(), await bcrypt.hash(pass, 10)]);
console.log(`Адміністратора ${email.toLowerCase()} створено/оновлено`);
await pool.end();
