// Змінити пароль користувача (наприклад, адміна): npm run set-password -- admin@shop.ua НовийПароль123
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { pool } from '../src/db.mjs';
const [email, pass] = process.argv.slice(2);
if (!email || !pass || pass.length < 8) { console.error('Використання: npm run set-password -- email новий_пароль (мін. 8 символів)'); process.exit(1); }
const r = await pool.query('update users set password_hash=$2 where email=$1', [email.toLowerCase(), await bcrypt.hash(pass, 10)]);
console.log(r.rowCount ? 'Пароль змінено' : 'Користувача не знайдено');
await pool.end();
