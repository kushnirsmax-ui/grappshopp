// Виконати SQL-файли без psql (зручно на хостингу, де є лише SSH і Node.js):
//   node scripts/db-init.mjs db/schema_shared.sql db/seed_prod.sql
import 'dotenv/config';
import fs from 'node:fs';
import { pool } from '../src/db.mjs';
const files = process.argv.slice(2);
if (!files.length) { console.error('Використання: node scripts/db-init.mjs файл.sql [файл2.sql ...]'); process.exit(1); }
for (const f of files) {
  process.stdout.write(`Виконую ${f} ... `);
  await pool.query(fs.readFileSync(f, 'utf8'));
  console.log('готово');
}
await pool.end();
