import { httpErr, str } from './util.mjs';
// Ціни та залишки беруться ТІЛЬКИ з бази, а не з даних браузера.
export async function priceItems(c, raw, lock = false) {
  if (!Array.isArray(raw) || !raw.length || raw.length > 50) throw httpErr(400, 'Кошик порожній');
  const m = new Map();
  for (const it of raw) {
    const id = Number(it?.id), qty = Number(it?.qty), size = str(it?.size, 50);
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 99 || !size) throw httpErr(400, 'Некоректна позиція кошика');
    const k = `${id}|${size}`;
    m.set(k, { id, size, qty: (m.get(k)?.qty || 0) + qty });
  }
  const L = [...m.values()];
  const { rows } = await c.query(
    `select v.id as vid, v.sku, v.size, v.stock, p.id as pid, p.name, p.price, p.cost_price
       from unnest($1::bigint[], $2::text[]) x(pid, size)
       join product_variants v on v.product_id = x.pid and v.size = x.size
       join products p on p.id = v.product_id and p.is_active ${lock ? 'for update of v' : ''}`,
    [L.map(i => i.id), L.map(i => i.size)]);
  const items = L.map(i => {
    const r = rows.find(r => r.pid === i.id && r.size === i.size);
    if (!r) throw httpErr(409, 'Один із товарів більше недоступний');
    if (r.stock < i.qty) throw httpErr(409, `Недостатньо товару «${r.name}» (розмір ${r.size}): залишилось ${r.stock}`);
    return { ...r, qty: i.qty };
  });
  return { items, subtotal: Math.round(items.reduce((a, i) => a + i.price * i.qty, 0) * 100) / 100 };
}
