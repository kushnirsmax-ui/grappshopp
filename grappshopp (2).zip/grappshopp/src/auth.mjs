import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { q } from './db.mjs';
import { httpErr } from './util.mjs';
const SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
export const signIn = (res, user) => {
  const t = jwt.sign({ uid: user.id }, SECRET, { expiresIn: '7d' });
  res.cookie('gp_token', t, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 864e5, path: '/' });
};
export const signOut = res => res.clearCookie('gp_token', { path: '/' });
export const hashCode = (uid, code) => crypto.createHash('sha256').update(`${uid}:${code}:${SECRET}`).digest('hex');
export const same = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
export async function attachUser(req, res, next) {
  req.user = null;
  try {
    const t = req.cookies?.gp_token;
    if (t) {
      const { uid } = jwt.verify(t, SECRET);
      const [u] = await q('select id,name,email,role,phone,city from users where id=$1 and is_active', [uid]);
      req.user = u || null;
    }
  } catch { /* недійсний токен — гість */ }
  next();
}
export const requireAuth = (req, res, next) => (req.user ? next() : next(httpErr(401, 'Потрібен вхід')));
export const requireAdmin = (req, res, next) => (req.user?.role === 'admin' ? next() : next(httpErr(req.user ? 403 : 401, 'Недостатньо прав')));
