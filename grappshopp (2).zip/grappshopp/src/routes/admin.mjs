import { Router } from 'express';
import sanitizeHtml from 'sanitize-html';
import { q, tx } from '../db.mjs';
import { requireAdmin } from '../auth.mjs';
import { saveImage, removeImage, isOwnImage } from '../uploads.mjs';
import { dispatchNewsletter } from '../newsletter.mjs';
import { h, httpErr, str, need, email, money, intId, slugify, GENDER, STATUS, ICONS } from '../util.mjs';

const r = Router();
r.use(requireAdmin);
const ok = res => res.json({ ok: true });

// ---------- Товари ----------
async function saveProduct(c, id, b, uid) {
  const name = need(b.name, 'Вкажіть назву', 200);
  const { rows: [cat] } = await c.query('select id from categories where name=$1', [str(b.cat, 100)]);
  if (!cat) throw httpErr(400, 'Розділ не знайдено');
  const g = GENDER[b.g] || 'unisex', icon = ICONS.includes(b.ic) ? b.ic : 'box';
  const price = money(b.price), old = b.old ? money(b.old) : null, cost = money(b.cost || 0);
  if (old !== null && old < price) throw httpErr(400, 'Стара ціна не може бути меншою за поточну');
  const sizes = Object.entries(b.st && typeof b.st === 'object' ? b.st : {}).slice(0, 30)
    .map(([s, n]) => [str(s, 50), Math.max(0, Math.min(100000, parseInt(n, 10) || 0))]).filter(([s]) => s);
  if (!sizes.length) throw httpErr(400, 'Вкажіть хоча б один розмір');
  const tags = [...new Set((Array.isArray(b.tags) ? b.tags : []).map(t => str(t, 40).toLowerCase().replace(/[#\s]/g, '')).filter(Boolean))].slice(0, 20);
  const sku = str(b.sku, 40).toUpperCase(), nw = !!b.nw, desc = str(b.desc, 5000);
  const saved = [];
  try {
    let pid = id, oldImgs = [];
    if (id) {
      const { rows: [ex] } = await c.query('select is_new from products where id=$1 for update', [id]);
      if (!ex) throw httpErr(404, 'Товар не знайдено');
      await c.query(`update products set sku=coalesce(nullif($2,''),sku), name=$3, description=$4, category_id=$5, gender=$6, price=$7,
        old_price=$8, cost_price=$9, icon=$10, is_new=$11, new_at=case when $11 and not $12 then now() else new_at end where id=$1`,
        [id, sku, name, desc, cat.id, g, price, old, cost, icon, nw, ex.is_new]);
      oldImgs = (await c.query('select url from product_images where product_id=$1', [id])).rows.map(x => x.url);
    } else {
      const { rows: [p] } = await c.query(`insert into products(sku,name,description,category_id,gender,price,old_price,cost_price,icon,hue,is_new,new_at)
        values(coalesce(nullif($1,''),next_product_sku()),$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,case when $11 then now() end) returning id`,
        [sku, name, desc, cat.id, g, price, old, cost, icon, 100 + Math.floor(Math.random() * 90), nw]);
      pid = p.id;
    }
    // розміри та залишки (зміни логуються в stock_movements)
    const ex = new Map((await c.query('select size,stock from product_variants where product_id=$1', [pid])).rows.map(x => [x.size, x.stock]));
    for (const [s, n] of sizes) {
      const { rows: [v] } = await c.query(`insert into product_variants(product_id,size,stock) values($1,$2,$3)
        on conflict (product_id,size) do update set stock=excluded.stock returning id`, [pid, s, n]);
      const d = n - (ex.get(s) || 0);
      if (d) await c.query(`insert into stock_movements(variant_id,delta,reason,created_by,note) values($1,$2,'manual',$3,'Редагування товару в адмінці')`, [v.id, d, uid]);
    }
    await c.query('delete from product_variants where product_id=$1 and size<>all($2::text[])', [pid, sizes.map(x => x[0])]);
    // фото: нові (data URL) зберігаються у файли, наявні /uploads/... залишаються
    const urls = [];
    for (const u of (Array.isArray(b.imgs) ? b.imgs : []).slice(0, 6)) {
      if (typeof u !== 'string') continue;
      if (u.startsWith('data:')) { const n = saveImage(u); saved.push(n); urls.push(n); }
      else if (isOwnImage(u)) urls.push(u);
    }
    await c.query('delete from product_images where product_id=$1', [pid]);
    for (const [i, u] of urls.entries()) await c.query('insert into product_images(product_id,url,sort_order) values($1,$2,$3)', [pid, u, i]);
    // хештеги
    await c.query('delete from product_tags where product_id=$1', [pid]);
    for (const t of tags) {
      const { rows: [tg] } = await c.query('insert into tags(name) values($1) on conflict (name) do update set name=excluded.name returning id', [t]);
      await c.query('insert into product_tags values($1,$2) on conflict do nothing', [pid, tg.id]);
    }
    return { pid, removed: oldImgs.filter(u => !urls.includes(u)) };
  } catch (e) { saved.forEach(removeImage); throw e; }
}
r.post('/products', h(async (req, res) => {
  const o = await tx(c => saveProduct(c, null, req.body, req.user.id));
  res.json({ id: o.pid });
}));
r.put('/products/:id', h(async (req, res) => {
  const o = await tx(c => saveProduct(c, intId(req.params.id), req.body, req.user.id));
  o.removed.forEach(removeImage);
  res.json({ id: o.pid });
}));
r.patch('/products/:id/new', h(async (req, res) => {
  const nw = !!req.body.nw, top = !!req.body.top;
  await q(`update products set is_new=$2, new_at=case when $2 and ($3 or not is_new) then now() else new_at end where id=$1`, [intId(req.params.id), nw, top]);
  ok(res);
}));
r.delete('/products/:id', h(async (req, res) => {
  const id = intId(req.params.id);
  const imgs = await q('select url from product_images where product_id=$1', [id]);
  await q('delete from products where id=$1', [id]);
  imgs.forEach(i => removeImage(i.url));
  ok(res);
}));

// ---------- Розділи ----------
r.post('/categories', h(async (req, res) => {
  const name = need(req.body.name, 'Вкажіть назву розділу', 60);
  await q('insert into categories(name,slug,sort_order) values($1,$2,(select coalesce(max(sort_order),0)+1 from categories))', [name, slugify(name)]);
  ok(res);
}));
r.delete('/categories', h(async (req, res) => {
  const name = str(req.query.name, 100);
  const [n] = await q('select count(*)::int as n from products p join categories c on c.id=p.category_id where c.name=$1', [name]);
  if (n.n) throw httpErr(409, 'У розділі є товари — спочатку перенесіть їх');
  await q('delete from categories where name=$1', [name]);
  ok(res);
}));

// ---------- Замовлення ----------
r.patch('/orders/:id/status', h(async (req, res) => {
  const st = STATUS[req.body.status];
  if (!st) throw httpErr(400, 'Невідомий статус');
  const rows = await q('update orders set status=$2 where id=$1 returning id', [intId(req.params.id), st]);
  if (!rows.length) throw httpErr(404, 'Замовлення не знайдено');
  ok(res);
}));

// ---------- Промокоди ----------
r.post('/promos', h(async (req, res) => {
  const b = req.body, code = str(b.code, 40).toUpperCase();
  if (!/^[A-Z0-9_-]{2,40}$/.test(code)) throw httpErr(400, 'Код: літери A–Z, цифри, дефіс або підкреслення');
  const type = b.type === 'sum' ? 'fixed' : 'percent', val = money(b.val);
  if (!val) throw httpErr(400, 'Вкажіть значення знижки');
  if (type === 'percent' && val > 100) throw httpErr(400, 'Відсоток не може бути більшим за 100');
  const max = parseInt(b.max, 10);
  await q('insert into promo_codes(code,discount_type,value,min_order_amount,max_uses,expires_at) values($1,$2,$3,$4,$5,$6)',
    [code, type, val, money(b.min || 0), max > 0 ? max : null, /^\d{4}-\d{2}-\d{2}$/.test(b.exp || '') ? b.exp : null]);
  ok(res);
}));
r.patch('/promos/:code/toggle', h(async (req, res) => { await q('update promo_codes set is_active=not is_active where code=$1', [req.params.code]); ok(res); }));
r.delete('/promos/:code', h(async (req, res) => { await q('delete from promo_codes where code=$1', [req.params.code]); ok(res); }));

// ---------- Банер ----------
const DEFAULT_BANNERS = [
  ['Рухайся. Відчувай. Виглядай.', 'Нова колекція взуття, одягу й аксесуарів', 'Дивитись колекцію', null, '#00d45f', '#0a0a0a', 'shoe'],
  ['Осінь / Зима', 'Парки, худі та тепле взуття', 'Одяг', 'Одяг', '#0a0a0a', '#2bff7e', 'jacket'],
  ['Sale до −25%', 'Вибрані моделі за новими цінами', 'Купити зі знижкою', null, 'linear-gradient(120deg,#0a0a0a,#0b5d2e)', '#ffffff', 'glasses'],
  ['Рюкзаки та аксесуари', 'Усе, що потрібно в дорогу', 'Аксесуари', 'Аксесуари', '#d9e0d6', '#0a0a0a', 'bag'],
  ['−10% на перше замовлення', 'Промокод WELCOME10 на оформленні', 'До каталогу', null, 'linear-gradient(120deg,#2bff7e,#00a84c)', '#0a0a0a', 'watch']];
r.post('/banners', h(async (req, res) => {
  const b = req.body, url = saveImage(b.img);
  try {
    await q(`insert into banners(title,subtitle,button_text,image_url,text_color,sort_order) values($1,$2,$3,$4,'#ffffff',(select coalesce(max(sort_order),0)+1 from banners))`,
      [str(b.title, 120), str(b.sub, 200), str(b.btn, 60), url]);
  } catch (e) { removeImage(url); throw e; }
  ok(res);
}));
r.post('/banners/reset', h(async (req, res) => {
  const old = await tx(async c => {
    const o = (await c.query('delete from banners returning image_url')).rows;
    for (const [i, d] of DEFAULT_BANNERS.entries())
      await c.query(`insert into banners(title,subtitle,button_text,category_id,background,text_color,icon,sort_order)
        values($1,$2,$3,(select id from categories where name=$4),$5,$6,$7,$8)`, [d[0], d[1], d[2], d[3], d[4], d[5], d[6], i + 1]);
    return o;
  });
  old.forEach(b => removeImage(b.image_url));
  ok(res);
}));
r.delete('/banners/:id', h(async (req, res) => {
  const rows = await q('delete from banners where id=$1 returning image_url', [intId(req.params.id)]);
  rows.forEach(b => removeImage(b.image_url));
  ok(res);
}));

// ---------- Новини ----------
r.post('/news', h(async (req, res) => {
  await q('insert into news_posts(title,body,author_id) values($1,$2,$3)', [need(req.body.title, 'Вкажіть заголовок', 200), need(req.body.text, 'Вкажіть текст', 5000), req.user.id]);
  ok(res);
}));
r.delete('/news/:id', h(async (req, res) => { await q('delete from news_posts where id=$1', [intId(req.params.id)]); ok(res); }));

// ---------- Підписники та розсилки ----------
r.post('/subscribers', h(async (req, res) => {
  await q(`insert into newsletter_subscribers(email,source) values($1,'manual') on conflict (email) do update set unsubscribed_at=null`, [email(req.body.email)]);
  ok(res);
}));
r.delete('/subscribers', h(async (req, res) => { await q('update newsletter_subscribers set unsubscribed_at=now() where email=$1', [str(req.query.email, 254).toLowerCase()]); ok(res); }));
r.post('/newsletters', h(async (req, res) => {
  const subject = need(req.body.subject, 'Вкажіть тему листа', 200), body = need(req.body.msg, 'Вкажіть текст листа', 20000);
  const out = await tx(async c => {
    const { rows: [n] } = await c.query('insert into newsletters(subject,body,created_by) values($1,$2,$3) returning id', [subject, body, req.user.id]);
    const { rowCount } = await c.query(`insert into newsletter_deliveries(newsletter_id,subscriber_id) select $1,id from newsletter_subscribers where unsubscribed_at is null`, [n.id]);
    if (!rowCount) throw httpErr(400, 'Підписників ще немає');
    await c.query('update newsletters set recipients_count=$2 where id=$1', [n.id, rowCount]);
    return { id: n.id, queued: rowCount };
  });
  setImmediate(() => dispatchNewsletter(out.id).catch(console.error));
  res.json({ queued: out.queued });
}));

// ---------- Звернення та облік ----------
r.delete('/feedback/:id', h(async (req, res) => { await q('delete from feedback_messages where id=$1', [intId(req.params.id)]); ok(res); }));
r.post('/expenses', h(async (req, res) => {
  const b = req.body, amt = money(b.amt);
  if (!amt) throw httpErr(400, 'Вкажіть суму');
  const date = /^\d{4}-\d{2}-\d{2}$/.test(b.date || '') ? b.date : new Date().toISOString().slice(0, 10);
  const [cat] = await q('select id from expense_categories where name=$1', [str(b.cat, 60)]);
  if (!cat) throw httpErr(400, 'Невідома категорія витрат');
  await q('insert into expenses(expense_date,category_id,amount,note,created_by) values($1,$2,$3,$4,$5)', [date, cat.id, amt, str(b.note, 300), req.user.id]);
  ok(res);
}));
r.delete('/expenses/:id', h(async (req, res) => { await q('delete from expenses where id=$1', [intId(req.params.id)]); ok(res); }));

// ---------- Налаштування та сторінки футера ----------
const CLEAN = {
  allowedTags: ['p', 'b', 'strong', 'i', 'em', 'u', 'br', 'ul', 'ol', 'li', 'h3', 'h4', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'details', 'summary', 'a'],
  allowedAttributes: { a: ['href'] }, allowedSchemes: ['http', 'https', 'mailto', 'tel']
};
r.put('/settings', h(async (req, res) => {
  const b = req.body, c = b.contacts || {}, so = b.socials || {}, sh = b.shipping || {};
  const url = (v, name) => {
    const s = str(v, 300);
    if (s && !/^https?:\/\/[^\s]+$/i.test(s)) throw httpErr(400, `${name}: посилання має починатися з http:// або https://`);
    return s;
  };
  const mail = str(c.email, 254);
  if (mail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) throw httpErr(400, 'Невірний email для контактів');
  const val = {
    contacts: { phone: str(c.phone, 40), email: mail, hours: str(c.hours, 100) },
    socials: { instagram: url(so.instagram, 'Instagram'), telegram: url(so.telegram, 'Telegram'), tiktok: url(so.tiktok, 'TikTok'), olx: url(so.olx, 'OLX') },
    shipping: { free_from: Math.max(0, Math.min(1e6, parseInt(sh.free_from, 10) || 0)) }
  };
  for (const [k, v] of Object.entries(val))
    await q('insert into store_settings(key,value) values($1,$2) on conflict (key) do update set value=excluded.value, updated_at=now()', [k, JSON.stringify(v)]);
  ok(res);
}));
r.put('/pages/:slug', h(async (req, res) => {
  const title = need(req.body.title, 'Вкажіть заголовок', 120);
  const body = sanitizeHtml(str(req.body.body, 30000), CLEAN).trim();
  if (!body) throw httpErr(400, 'Текст сторінки порожній');
  const rows = await q('update site_pages set title=$2, body=$3, updated_at=now() where slug=$1 returning slug', [str(req.params.slug, 40), title, body]);
  if (!rows.length) throw httpErr(404, 'Сторінку не знайдено');
  ok(res);
}));

export default r;
