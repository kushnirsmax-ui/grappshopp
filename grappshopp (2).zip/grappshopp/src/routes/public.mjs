import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { q, tx, pool } from '../db.mjs';
import { signIn, signOut, requireAuth, hashCode, same } from '../auth.mjs';
import { sendMail } from '../mail.mjs';
import { priceItems } from '../orders.mjs';
import { buildState } from '../serialize.mjs';
import { h, httpErr, str, need, email, SHIP, PAY } from '../util.mjs';

const r = Router();
const authLimit = rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Забагато спроб. Спробуйте пізніше' } });
const DUMMY = bcrypt.hashSync('dummy-password', 10);
const attempts = new Map();   // спроби введення коду відновлення
const strong = p => { if (p.length < 6) throw httpErr(400, 'Пароль має містити щонайменше 6 символів'); return p; };

r.get('/state', h(async (req, res) => res.json(await buildState(req.user))));

// ---------- Авторизація ----------
r.post('/auth/register', authLimit, h(async (req, res) => {
  const b = req.body;
  const name = need(b.name, 'Вкажіть імʼя', 100), mail = email(b.email), pass = strong(str(b.pass, 200));
  const hash = await bcrypt.hash(pass, 10);
  const [u] = await q('insert into users(name,email,password_hash) values($1,$2,$3) returning id,name,email,role,phone,city', [name, mail, hash]);
  if (b.nl) await q(`insert into newsletter_subscribers(email,user_id,source) values($1,$2,'registration')
    on conflict (email) do update set unsubscribed_at=null, user_id=coalesce(newsletter_subscribers.user_id, excluded.user_id)`, [mail, u.id]);
  signIn(res, u);
  res.json({ ok: true });
}));

r.post('/auth/login', authLimit, h(async (req, res) => {
  const [u] = await q('select id,password_hash from users where email=$1 and is_active', [email(req.body.email)]);
  const ok = await bcrypt.compare(str(req.body.pass, 200), u ? u.password_hash : DUMMY);
  if (!u || !ok) throw httpErr(401, 'Невірний email або пароль');
  signIn(res, u);
  res.json({ ok: true });
}));

r.post('/auth/logout', (req, res) => { signOut(res); res.json({ ok: true }); });

r.post('/auth/forgot', authLimit, h(async (req, res) => {
  const mail = email(req.body.email);
  const [u] = await q('select id from users where email=$1 and is_active', [mail]);
  let devCode;
  if (u) {
    const code = String(crypto.randomInt(100000, 1000000));
    await q('update password_resets set used_at=now() where user_id=$1 and used_at is null', [u.id]);
    await q(`insert into password_resets(user_id,code_hash,expires_at) values($1,$2,now()+interval '15 minutes')`, [u.id, hashCode(u.id, code)]);
    try {
      await sendMail({ to: mail, subject: 'Відновлення пароля GRAPPSHOPP', text: `Код для відновлення пароля: ${code}\nВін дійсний 15 хвилин. Якщо ви не робили запит, просто проігноруйте цей лист.` });
    } catch (e) {
      console.error('[mail]', e.message);
      if (process.env.NODE_ENV !== 'production') devCode = code;   // тільки для розробки
    }
  }
  res.json({ ok: true, devCode });   // відповідь однакова, чи існує акаунт
}));

r.post('/auth/reset', authLimit, h(async (req, res) => {
  const mail = email(req.body.email), code = str(req.body.code, 10), pass = strong(str(req.body.pass, 200));
  const [u] = await q('select id from users where email=$1 and is_active', [mail]);
  const [pr] = u ? await q('select id,code_hash from password_resets where user_id=$1 and used_at is null and expires_at>now() order by id desc limit 1', [u.id]) : [];
  if (!pr || !same(pr.code_hash, hashCode(u.id, code))) {
    if (pr) {
      const n = (attempts.get(u.id) || 0) + 1; attempts.set(u.id, n);
      if (n >= 5) { await q('update password_resets set used_at=now() where id=$1', [pr.id]); attempts.delete(u.id); }
    }
    throw httpErr(400, 'Невірний або прострочений код');
  }
  attempts.delete(u.id);
  await tx(async c => {
    await c.query('update users set password_hash=$1 where id=$2', [await bcrypt.hash(pass, 10), u.id]);
    await c.query('update password_resets set used_at=now() where user_id=$1 and used_at is null', [u.id]);
  });
  res.json({ ok: true });
}));

r.put('/me', requireAuth, h(async (req, res) => {
  const b = req.body;
  await q('update users set name=$2, phone=$3, city=$4 where id=$1', [req.user.id, need(b.name, 'Вкажіть імʼя', 100), str(b.phone, 40), str(b.city, 100)]);
  res.json({ ok: true });
}));

// ---------- Промокод і замовлення ----------
r.post('/promo/check', h(async (req, res) => {
  const { subtotal } = await priceItems(pool, req.body.items);
  const code = str(req.body.code, 40);
  const [p] = await q('select * from promo_check($1,$2)', [code, subtotal]);
  if (p.error) throw httpErr(400, p.error);
  res.json({ code: code.toUpperCase(), discount: p.discount });
}));

r.post('/orders', h(async (req, res) => {
  const b = req.body;
  const name = need(b.name, 'Вкажіть імʼя', 100), phone = need(b.phone, 'Вкажіть телефон', 40),
    city = need(b.city, 'Вкажіть місто', 100), branch = need(b.branch, 'Вкажіть відділення або адресу', 200);
  const ship = SHIP[b.ship], pay = PAY[b.pay];
  if (!ship || !pay) throw httpErr(400, 'Оберіть доставку та оплату');
  const out = await tx(async c => {
    const { items, subtotal } = await priceItems(c, b.items, true);
    let promoId = null, discount = 0;
    const code = str(b.promo, 40);
    if (code) {
      const { rows: [p] } = await c.query('select * from promo_check($1,$2)', [code, subtotal]);
      if (p.error) throw httpErr(400, p.error);
      promoId = p.promo_id; discount = p.discount;
    }
    const total = Math.round((subtotal - discount) * 100) / 100;
    const { rows: [o] } = await c.query(
      `insert into orders(user_id,customer_name,phone,delivery_city,delivery_branch,shipping,payment,promo_code_id,subtotal,discount,total)
       values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) returning id`,
      [req.user?.id || null, name, phone, city, branch, ship, pay, promoId, subtotal, discount, total]);
    for (const i of items) {
      await c.query(`insert into order_items(order_id,variant_id,product_name,sku,size,quantity,unit_price,unit_cost) values($1,$2,$3,$4,$5,$6,$7,$8)`,
        [o.id, i.vid, i.name, i.sku, i.size, i.qty, i.price, i.cost_price]);
    }
    return { id: o.id, total, items };
  });
  if (process.env.ADMIN_EMAIL) {
    sendMail({ to: process.env.ADMIN_EMAIL, subject: `Нове замовлення №${out.id}`,
      text: `${name}, ${phone}\n${city}, ${branch}\n${out.items.map(i => `${i.name} (${i.size}) × ${i.qty}`).join('\n')}\nРазом: ${out.total} ₴` }).catch(() => {});
  }
  res.json({ id: out.id, total: out.total });
}));

// ---------- Підписка, відписка, зворотний зв'язок ----------
r.post('/subscribe', rateLimit({ windowMs: 60_000, limit: 10 }), h(async (req, res) => {
  await q(`insert into newsletter_subscribers(email,source) values($1,'site')
    on conflict (email) do update set unsubscribed_at=null, subscribed_at=case when newsletter_subscribers.unsubscribed_at is null then newsletter_subscribers.subscribed_at else now() end`, [email(req.body.email)]);
  res.json({ ok: true });
}));

const unsub = h(async (req, res) => {
  if (!/^[0-9a-f-]{36}$/i.test(req.params.token)) throw httpErr(404, 'Не знайдено');
  await q('update newsletter_subscribers set unsubscribed_at=now() where unsubscribe_token=$1 and unsubscribed_at is null', [req.params.token]);
  res.type('html').send('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font:18px sans-serif;max-width:480px;margin:15vh auto;padding:0 20px"><h2>Ви відписалися від розсилки GRAPPSHOPP</h2><p><a href="/">Повернутися на сайт</a></p>');
});
r.get('/unsubscribe/:token', unsub);
r.post('/unsubscribe/:token', unsub);

r.post('/feedback', rateLimit({ windowMs: 60_000, limit: 5 }), h(async (req, res) => {
  const b = req.body;
  await q('insert into feedback_messages(user_id,name,email,message) values($1,$2,$3,$4)', [req.user?.id || null, need(b.name, 'Вкажіть імʼя', 100), email(b.email), need(b.msg, 'Напишіть повідомлення', 3000)]);
  if (process.env.ADMIN_EMAIL) sendMail({ to: process.env.ADMIN_EMAIL, subject: 'Нове звернення на сайті', text: `${str(b.name)} <${str(b.email)}>\n\n${str(b.msg, 3000)}` }).catch(() => {});
  res.json({ ok: true });
}));

export default r;
