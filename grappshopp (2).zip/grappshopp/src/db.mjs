import pg from 'pg';
pg.types.setTypeParser(20, v => parseInt(v, 10));    // bigint -> number
pg.types.setTypeParser(1700, v => parseFloat(v));     // numeric -> number
pg.types.setTypeParser(1082, v => v);                 // date -> 'YYYY-MM-DD'
export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: Number(process.env.DB_POOL_MAX || 10) });
export const q = (text, params) => pool.query(text, params).then(r => r.rows);
export async function tx(fn) {
  const c = await pool.connect();
  try { await c.query('begin'); const r = await fn(c); await c.query('commit'); return r; }
  catch (e) { await c.query('rollback').catch(() => {}); throw e; }
  finally { c.release(); }
}
