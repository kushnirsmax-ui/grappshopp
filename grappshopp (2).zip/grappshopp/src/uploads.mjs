import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { httpErr } from './util.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(here, '../uploads'));
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const OWN = /^\/uploads\/[\w-]+\.(jpg|png|gif|webp)$/;
const MAGIC = [['jpg', [0xff, 0xd8, 0xff]], ['png', [0x89, 0x50, 0x4e, 0x47]], ['gif', [0x47, 0x49, 0x46, 0x38]]];
export const isOwnImage = u => OWN.test(u || '');
export function saveImage(dataUrl) {
  const m = /^data:image\/(?:jpeg|png|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) throw httpErr(400, 'Некоректне зображення');
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length > 6 * 1024 * 1024) throw httpErr(413, 'Фото завелике (макс. 6 МБ)');
  let ext = MAGIC.find(([, b]) => b.every((x, i) => buf[i] === x))?.[0];
  if (!ext && buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') ext = 'webp';
  if (!ext) throw httpErr(400, 'Непідтримуваний формат зображення');
  const name = `${crypto.randomUUID()}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  return `/uploads/${name}`;
}
export const removeImage = u => { if (isOwnImage(u)) fs.unlink(path.join(UPLOAD_DIR, path.basename(u)), () => {}); };
