import { pool } from './db.mjs';
import { sendMail } from './mail.mjs';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const BASE = () => (process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
// Розсилка: кожному підписнику окремий лист з персональним посиланням відписки.
export async function dispatchNewsletter(id) {
  const { rows } = await pool.query(
    `select d.subscriber_id as sid, s.email, s.unsubscribe_token as tok, n.subject, n.body
       from newsletter_deliveries d
       join newsletter_subscribers s on s.id = d.subscriber_id and s.unsubscribed_at is null
       join newsletters n on n.id = d.newsletter_id
      where d.newsletter_id = $1 and d.status = 'pending' order by s.id`, [id]);
  for (const r of rows) {
    try {
      const link = `${BASE()}/api/unsubscribe/${r.tok}`;
      await sendMail({
        to: r.email, subject: r.subject,
        text: `${r.body}\n\n—\nGRAPPSHOPP\nВідписатися від розсилки: ${link}`,
        headers: { 'List-Unsubscribe': `<${link}>`, 'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click' }
      });
      await pool.query(`update newsletter_deliveries set status='sent', sent_at=now() where newsletter_id=$1 and subscriber_id=$2`, [id, r.sid]);
    } catch (e) {
      await pool.query(`update newsletter_deliveries set status='failed', error=$3 where newsletter_id=$1 and subscriber_id=$2`, [id, r.sid, String(e.message).slice(0, 300)]);
    }
    await sleep(Number(process.env.MAIL_DELAY_MS || 300));
  }
  await pool.query(`update newsletters set sent_at=now(), recipients_count=(select count(*) from newsletter_deliveries where newsletter_id=$1 and status='sent') where id=$1`, [id]);
}
export async function resumeNewsletters() {
  const { rows } = await pool.query(`select distinct newsletter_id from newsletter_deliveries where status='pending'`);
  for (const r of rows) dispatchNewsletter(r.newsletter_id).catch(console.error);
}
