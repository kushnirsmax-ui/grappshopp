export const httpErr = (status, message) => Object.assign(new Error(message), { status });
export const h = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
export const str = (v, max = 200) => String(v ?? '').trim().slice(0, max);
export const need = (v, msg, max) => { const s = str(v, max); if (!s) throw httpErr(400, msg); return s; };
export const email = v => {
  const s = str(v, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) throw httpErr(400, 'Невірний email');
  return s;
};
export const money = v => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || n > 1e8) throw httpErr(400, 'Невірна сума');
  return Math.round(n * 100) / 100;
};
export const intId = v => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw httpErr(400, 'Невірний ідентифікатор'); return n; };
export const dt = ts => new Date(ts).toLocaleDateString('uk-UA', { timeZone: 'Europe/Kyiv' });
export const GENDER = { w: 'women', m: 'men', u: 'unisex' };
export const GENDER_R = { women: 'w', men: 'm', unisex: 'u' };
export const STATUS = { 'Нове': 'new', 'Відправлено': 'shipped', 'Доставлено': 'delivered', 'Скасовано': 'cancelled' };
export const STATUS_R = Object.fromEntries(Object.entries(STATUS).map(([k, v]) => [v, k]));
export const SHIP = { 'Нова пошта': 'nova_poshta', 'Укрпошта': 'ukrposhta' };
export const PAY = { 'Накладений платіж': 'cod', 'Картка онлайн': 'card_online' };
export const ICONS = ['shoe', 'jacket', 'tee', 'pants', 'bag', 'cap', 'glasses', 'watch', 'dress', 'box'];
const TR = { а:'a',б:'b',в:'v',г:'h',ґ:'g',д:'d',е:'e',є:'ye',ж:'zh',з:'z',и:'y',і:'i',ї:'yi',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'kh',ц:'ts',ч:'ch',ш:'sh',щ:'shch',ь:'',ю:'yu',я:'ya','ʼ':'','’':'' };
export const slugify = s => [...s.toLowerCase()].map(c => TR[c] ?? c).join('').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'c' + Date.now().toString(36);
