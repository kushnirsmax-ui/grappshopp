import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import bcrypt from 'bcryptjs';
import { pool } from './db.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const migrations = () => { try { return fs.readdirSync(path.join(root, 'db/migrations')).filter(f => f.endsWith('.sql')).sort(); } catch { return []; } };
async function runSql(sql) {   // окреме з'єднання: при помилці відкочуємо транзакцію з файлу
  const c = await pool.connect();
  try { await c.query(sql); }
  catch (e) { await c.query('rollback').catch(() => {}); throw e; }
  finally { c.release(); }
}
// Автоматична підготовка бази при запуску (потрібна, де немає зручного доступу до консолі, напр. Railway).
// AUTO_DB_INIT=1: створює схему й початкові дані, якщо бази ще немає; далі застосовує нові файли з db/migrations.
// INITIAL_ADMIN_EMAIL + INITIAL_ADMIN_PASSWORD (від 10 символів): створює адміна, якщо жодного ще немає.
export async function bootstrap() {
  if (process.env.AUTO_DB_INIT === '1') {
    const { rows: [t] } = await pool.query(`select to_regclass('public.users') as t`);
    if (!t.t) {
      console.log('[init] база порожня — створюю схему й початкові дані');
      await runSql(read('db/schema_shared.sql'));
      await runSql(read('db/seed_prod.sql'));
      await pool.query('create table if not exists schema_migrations(name text primary key, applied_at timestamptz not null default now())');
      for (const f of migrations()) await pool.query('insert into schema_migrations(name) values($1) on conflict do nothing', [f]);
    } else {
      await pool.query('create table if not exists schema_migrations(name text primary key, applied_at timestamptz not null default now())');
      const done = new Set((await pool.query('select name from schema_migrations')).rows.map(r => r.name));
      for (const f of migrations().filter(f => !done.has(f))) {
        console.log(`[init] застосовую міграцію ${f}`);
        await runSql(read(`db/migrations/${f}`));
        await pool.query('insert into schema_migrations(name) values($1)', [f]);
      }
    }
  }
  const { INITIAL_ADMIN_EMAIL: em, INITIAL_ADMIN_PASSWORD: pw } = process.env;
  if (em && pw) {
    if (pw.length < 10) { console.warn('[init] INITIAL_ADMIN_PASSWORD коротший за 10 символів — адміна не створено'); return; }
    const { rows } = await pool.query(`select 1 from users where role='admin' limit 1`);
    if (!rows.length) {
      await pool.query(`insert into users(name,email,password_hash,role) values('Адміністратор',$1,$2,'admin') on conflict (email) do update set role='admin', password_hash=excluded.password_hash, is_active=true`, [em.toLowerCase(), await bcrypt.hash(pw, 10)]);
      console.log(`[init] створено адміністратора ${em.toLowerCase()} — приберіть INITIAL_ADMIN_PASSWORD зі змінних`);
    }
  }
}
