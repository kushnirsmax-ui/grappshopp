import { q } from './db.mjs';
import { GENDER_R, STATUS_R, dt } from './util.mjs';
const SHIP_R = { nova_poshta: 'Нова пошта', ukrposhta: 'Укрпошта' };
const PAY_R = { cod: 'Накладений платіж', card_online: 'Картка онлайн' };
const SRC = { site: 'сайт', registration: 'реєстрація', manual: 'вручну' };

const PRODUCTS = `select p.id,p.sku,p.name,p.description,p.price,p.old_price,p.cost_price,p.icon,p.hue,p.gender,p.is_new,
  extract(epoch from coalesce(p.new_at,p.created_at))*1000 as new_ms, c.name as category,
  coalesce((select json_object_agg(v.size,v.stock order by v.id) from product_variants v where v.product_id=p.id),'{}') as st,
  coalesce((select json_agg(i.url order by i.sort_order,i.id) from product_images i where i.product_id=p.id),'[]') as imgs,
  coalesce((select json_agg(t.name order by t.name) from product_tags pt join tags t on t.id=pt.tag_id where pt.product_id=p.id),'[]') as tags
  from products p join categories c on c.id=p.category_id where p.is_active order by p.id`;
const ORDERS = where => `select * from (select o.*, extract(epoch from o.created_at)*1000 as ts,
  coalesce(json_agg(json_build_object('name',oi.product_name,'sku',oi.sku,'size',oi.size,'qty',oi.quantity,'cost',oi.unit_cost,'price',oi.unit_price) order by oi.id) filter (where oi.id is not null),'[]') as items
  from orders o left join order_items oi on oi.order_id=o.id ${where} group by o.id order by o.id desc limit 2000) t order by id`;

const prodOut = (r, admin) => ({
  id: r.id, sku: r.sku, name: r.name, desc: r.description, cat: r.category, g: GENDER_R[r.gender],
  price: r.price, old: r.old_price || 0, ic: r.icon, hue: r.hue, nw: r.is_new, nwAt: Math.round(r.new_ms),
  st: r.st, imgs: r.imgs, tags: r.tags, ...(admin ? { cost: r.cost_price } : {})
});
const ordOut = o => ({
  id: o.id, uid: o.user_id, name: o.customer_name, phone: o.phone, city: o.delivery_city, branch: o.delivery_branch,
  ship: SHIP_R[o.shipping], pay: PAY_R[o.payment], items: o.items, promo: o.promo_code || '', disc: o.discount,
  total: o.total, status: STATUS_R[o.status], ts: Math.round(o.ts), date: dt(o.ts)
});

export async function buildState(user) {
  const admin = user?.role === 'admin';
  const [cats, prods, banners, news, settings, pages, orders] = await Promise.all([
    q('select name from categories order by sort_order,id'),
    q(PRODUCTS),
    q(`select b.*,c.name as link from banners b left join categories c on c.id=b.category_id where b.is_active order by b.sort_order,b.id`),
    q(`select id,title,body,published_at from news_posts where is_published order by published_at desc limit 20`),
    q('select key,value from store_settings'),
    q('select slug,title,body from site_pages order by sort_order'),
    !user ? [] : admin ? q(ORDERS('')) : q(ORDERS('where o.user_id=$1'), [user.id])
  ]);
  const state = {
    me: user ? { id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone || '', city: user.city || '' } : null,
    cats: cats.map(c => c.name),
    products: prods.map(p => prodOut(p, admin)),
    banners: banners.map(b => ({ id: b.id, title: b.title, sub: b.subtitle, btn: b.button_text, link: b.link || '', bg: b.background, fg: b.text_color, ic: b.icon, img: b.image_url })),
    news: news.map(n => ({ id: n.id, ts: +n.published_at, date: dt(n.published_at), title: n.title, text: n.body })),
    settings: Object.fromEntries(settings.map(s => [s.key, s.value])),
    pages: Object.fromEntries(pages.map(p => [p.slug, { title: p.title, body: p.body }])),
    orders: orders.map(ordOut)
  };
  if (admin) {
    const [users, promos, subs, letters, fb, exps] = await Promise.all([
      q('select id,name,email,role from users order by id'),
      q('select * from promo_codes order by id'),
      q('select email,subscribed_at,source from newsletter_subscribers where unsubscribed_at is null order by id'),
      q('select id,subject,body,recipients_count,created_at from newsletters order by id'),
      q('select id,name,email,message,created_at from feedback_messages order by id'),
      q(`select e.id,e.amount,e.note,ec.name as cat,extract(epoch from e.expense_date::timestamp + interval '12 hours')*1000 as ts
         from expenses e join expense_categories ec on ec.id=e.category_id order by e.expense_date,e.id`)
    ]);
    state.users = users;
    state.promos = promos.map(p => ({ code: p.code, type: p.discount_type === 'percent' ? 'pct' : 'sum', val: p.value, min: p.min_order_amount, max: p.max_uses || 0, used: p.used_count, on: p.is_active ? 1 : 0, exp: p.expires_at || '' }));
    state.subscribers = subs.map(s => ({ email: s.email, date: dt(s.subscribed_at), src: SRC[s.source] }));
    state.newsletters = letters.map(n => ({ id: n.id, date: dt(n.created_at), subject: n.subject, msg: n.body, n: n.recipients_count }));
    state.feedback = fb.map(f => ({ id: f.id, date: dt(f.created_at), name: f.name, email: f.email, msg: f.message }));
    state.expenses = exps.map(e => ({ id: e.id, ts: Math.round(e.ts), cat: e.cat, amt: e.amount, note: e.note }));
  }
  return state;
}
