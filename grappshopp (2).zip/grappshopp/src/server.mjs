import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { UPLOAD_DIR } from './uploads.mjs';
import { attachUser } from './auth.mjs';
import { pool } from './db.mjs';
import { bootstrap } from './bootstrap.mjs';
import { resumeNewsletters } from './newsletter.mjs';
import publicRoutes from './routes/public.mjs';
import adminRoutes from './routes/admin.mjs';

if (!process.env.BASE_URL && process.env.RAILWAY_PUBLIC_DOMAIN) process.env.BASE_URL = `https://${process.env.RAILWAY_PUBLIC_DOMAIN}`;
const prod = process.env.NODE_ENV === 'production';
if (!process.env.DATABASE_URL) throw new Error('Не задано DATABASE_URL');
if (prod && (process.env.JWT_SECRET || '').length < 32) throw new Error('JWT_SECRET має містити щонайменше 32 символи');
const here = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:', 'blob:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"],
  upgradeInsecureRequests: prod ? [] : null } } }));
app.use(cookieParser());
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '30d', immutable: true, index: false }));
app.use(express.static(path.join(here, '../public')));

// Перевірка стану для Docker і моніторингу (UptimeRobot тощо)
app.get('/api/health', async (req, res) => {
  try { await pool.query('select 1'); res.json({ ok: true }); } catch { res.status(503).json({ ok: false }); }
});
app.use('/api', rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false }));
// Захист від CSRF: змінюючі запити тільки зі спеціальним заголовком (його не можна підробити з чужого сайту)
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || req.path.startsWith('/unsubscribe/')) return next();
  if (req.get('x-requested-with') !== 'gp') return res.status(403).json({ error: 'Заборонено' });
  next();
});
app.use('/api/admin', express.json({ limit: '30mb' }), attachUser, adminRoutes);
app.use('/api', express.json({ limit: '100kb' }), attachUser, publicRoutes);
app.use('/api', (req, res) => res.status(404).json({ error: 'Не знайдено' }));

app.use((err, req, res, next) => {   // eslint-disable-line no-unused-vars
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Запит завеликий' });
  if (err.status) return res.status(err.status).json({ error: err.message });
  if (err.code === '23505') {
    const c = err.constraint || '';
    const m = c.includes('sku') ? 'Такий артикул уже існує' : c.includes('email') ? 'Такий email уже зареєстровано'
      : c.includes('promo') ? 'Такий промокод уже існує' : c.includes('categories') ? 'Такий розділ уже є' : 'Такий запис уже існує';
    return res.status(409).json({ error: m });
  }
  if (err.code === '23514') return res.status(409).json({ error: 'Недостатньо товару на складі' });
  if (err.code === 'P0001') return res.status(400).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Помилка сервера' });
});

const port = Number(process.env.PORT || 3000);
bootstrap()
  .then(() => app.listen(port, () => { console.log(`GRAPPSHOPP: http://localhost:${port}`); resumeNewsletters().catch(console.error); }))
  .catch(e => { console.error('[init] помилка запуску:', e); process.exit(1); });
