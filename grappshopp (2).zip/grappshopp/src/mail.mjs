import nodemailer from 'nodemailer';
// Способи відправки (за пріоритетом): Resend API, Brevo API, SMTP, режим «лише в консоль».
// На Railway (тариф Hobby) SMTP заблоковано, тому там потрібен Resend або Brevo (HTTPS).
const smtp = process.env.SMTP_URL ? nodemailer.createTransport(process.env.SMTP_URL) : null;
const FROM = () => process.env.MAIL_FROM || 'GRAPPSHOPP <no-reply@localhost>';
const parseFrom = s => { const m = /^\s*(.*?)\s*<([^>]+)>\s*$/.exec(s); return m ? { name: m[1].replace(/^"|"$/g, ''), email: m[2] } : { name: '', email: s.trim() }; };
async function post(url, headers, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`Поштовий сервіс відповів ${r.status}: ${(await r.text()).slice(0, 200)}`);
}
export const mailMode = () => process.env.RESEND_API_KEY ? 'resend' : process.env.BREVO_API_KEY ? 'brevo' : smtp ? 'smtp' : process.env.MAIL_DRY_RUN === '1' ? 'dry' : 'none';
export async function sendMail({ to, subject, text, headers }) {
  const mode = mailMode();
  if (mode === 'resend') {
    return post(process.env.RESEND_API_URL || 'https://api.resend.com/emails', { Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
      { from: FROM(), to: [to], subject, text, ...(headers ? { headers } : {}) });
  }
  if (mode === 'brevo') {
    const f = parseFrom(FROM());
    return post(process.env.BREVO_API_URL || 'https://api.brevo.com/v3/smtp/email', { 'api-key': process.env.BREVO_API_KEY },
      { sender: f.name ? { name: f.name, email: f.email } : { email: f.email }, to: [{ email: to }], subject, textContent: text, ...(headers ? { headers } : {}) });
  }
  if (mode === 'smtp') return smtp.sendMail({ from: FROM(), to, subject, text, headers });
  if (mode === 'dry') { console.log(`[mail dry-run] до: ${to}\nтема: ${subject}\n${text}\n`); return; }
  throw new Error('Пошта не налаштована (задайте RESEND_API_KEY, BREVO_API_KEY або SMTP_URL)');
}
