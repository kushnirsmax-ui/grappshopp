#!/usr/bin/env bash
# Резервна копія бази й фото: deploy/backup.sh   (папка backups/, зберігаються останні 14 днів)
set -euo pipefail
cd "$(dirname "$0")/.."
C="docker compose -f docker-compose.prod.yml"
DIR="${BACKUP_DIR:-./backups}"; KEEP="${KEEP_DAYS:-14}"; TS="$(date +%F_%H%M)"
mkdir -p "$DIR"
$C exec -T db pg_dump -U grappshopp -Fc grappshopp > "$DIR/db_$TS.dump"
$C exec -T app tar czf - -C /data uploads > "$DIR/uploads_$TS.tgz"
find "$DIR" -type f \( -name 'db_*.dump' -o -name 'uploads_*.tgz' \) -mtime +"$KEEP" -delete
echo "$(date '+%F %T') OK: $DIR/db_$TS.dump, $DIR/uploads_$TS.tgz"
