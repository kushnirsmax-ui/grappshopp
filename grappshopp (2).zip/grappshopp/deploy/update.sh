#!/usr/bin/env bash
# Оновлення після заміни файлів проєкту (.env і дані зберігаються): deploy/update.sh
set -euo pipefail
cd "$(dirname "$0")/.."
bash deploy/backup.sh
docker compose -f docker-compose.prod.yml up -d --build
docker image prune -f >/dev/null
sleep 5
docker compose -f docker-compose.prod.yml ps
