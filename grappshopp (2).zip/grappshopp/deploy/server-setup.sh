#!/usr/bin/env bash
# Первинне налаштування чистого сервера Ubuntu 22.04/24.04 (запускати від root):
#   bash server-setup.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Запустіть від root (sudo bash server-setup.sh)"; exit 1; }
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get -y upgrade
apt-get install -y ca-certificates curl ufw fail2ban unattended-upgrades unzip
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
systemctl enable --now docker fail2ban
# Брандмауер: SSH, HTTP, HTTPS. База даних назовні не відкривається.
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
dpkg-reconfigure -f noninteractive unattended-upgrades || true
echo "Готово. Далі: розпакуйте проєкт у /opt/grappshopp і заповніть .env (див. DEPLOY.md)."
