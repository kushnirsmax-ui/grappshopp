#!/usr/bin/env bash
# Резервна копія на хостингу без Docker (запускайте через cron у панелі):
#   bash ~/grappshopp/deploy/backup-shared.sh
# Потрібні: pg_dump (є на більшості хостингів із PostgreSQL) і змінна DATABASE_URL у .env
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./.env; set +a
DIR="${BACKUP_DIR:-$HOME/grappshopp-backups}"; KEEP="${KEEP_DAYS:-14}"; TS="$(date +%F_%H%M)"
mkdir -p "$DIR"
pg_dump "$DATABASE_URL" -Fc -f "$DIR/db_$TS.dump"
tar czf "$DIR/uploads_$TS.tgz" -C "${UPLOAD_DIR:-./uploads}/.." "$(basename "${UPLOAD_DIR:-./uploads}")"
find "$DIR" -type f \( -name 'db_*.dump' -o -name 'uploads_*.tgz' \) -mtime +"$KEEP" -delete
echo "$(date '+%F %T') OK: $DIR/db_$TS.dump"
