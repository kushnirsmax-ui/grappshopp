#!/usr/bin/env bash
# Відновлення з копії: deploy/restore.sh backups/db_ДАТА.dump [backups/uploads_ДАТА.tgz]
# УВАГА: поточну базу буде замінено.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f "${1:-}" ] || { echo "Вкажіть файл копії бази (db_*.dump)"; exit 1; }
read -r -p "Поточні дані буде замінено. Продовжити? [y/N] " a; [ "$a" = "y" ] || exit 1
C="docker compose -f docker-compose.prod.yml"
$C stop app
$C exec -T db psql -U grappshopp -d postgres -c "drop database if exists grappshopp with (force)" -c "create database grappshopp"
$C exec -T db pg_restore -U grappshopp -d grappshopp --no-owner < "$1"
if [ -n "${2:-}" ]; then
  $C run --rm --no-deps -T app sh -c 'rm -rf /data/uploads/* && tar xzf - -C /data' < "$2"
fi
$C start app
echo "Відновлено."
