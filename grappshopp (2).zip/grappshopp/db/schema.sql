-- =====================================================================
-- GRAPPSHOPP · схема бази даних (PostgreSQL 14+)
-- Запуск:
--   createdb grappshopp
--   psql -d grappshopp -v ON_ERROR_STOP=1 -f grappshopp_schema.sql
--   psql -d grappshopp -v ON_ERROR_STOP=1 -f grappshopp_seed.sql
-- Усі гроші — numeric(12,2) у гривнях. Час — timestamptz.
-- Фото зберігаються у файловому сховищі/S3, в базі лише посилання (url).
-- Паролі: тільки хеш (bcrypt/argon2), ніколи відкритий текст.
-- =====================================================================
begin;

create extension if not exists citext;
create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- ---------- Типи ----------
create type user_role         as enum ('customer', 'admin');
create type gender_type       as enum ('women', 'men', 'unisex');
create type order_status      as enum ('new', 'shipped', 'delivered', 'cancelled');
create type shipping_method   as enum ('nova_poshta', 'ukrposhta');
create type payment_method    as enum ('cod', 'card_online');
create type discount_type     as enum ('percent', 'fixed');
create type subscriber_source as enum ('site', 'registration', 'manual');
create type delivery_status   as enum ('pending', 'sent', 'failed');
create type feedback_status   as enum ('new', 'read', 'answered');
create type stock_reason      as enum ('order', 'order_cancelled', 'manual', 'purchase', 'correction');

-- ---------- Службові функції ----------
create function set_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Артикули товарів: GS-0001, GS-0002 ...
create sequence product_sku_seq;
create function next_product_sku() returns text language sql as $$
  select 'GS-' || lpad(nextval('product_sku_seq')::text, 4, '0')
$$;

-- =====================================================================
-- 1. Користувачі
-- =====================================================================
create table users (
  id            bigint generated always as identity primary key,
  name          text        not null check (length(trim(name)) > 0),
  email         citext      not null unique,
  password_hash text        not null,
  role          user_role   not null default 'customer',
  phone         text,
  city          text,
  is_active     boolean     not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger users_updated before update on users
  for each row execute function set_updated_at();

-- Відновлення пароля (код з листа зберігаємо лише у вигляді хеша)
create table password_resets (
  id         bigint generated always as identity primary key,
  user_id    bigint      not null references users(id) on delete cascade,
  code_hash  text        not null,
  expires_at timestamptz not null,
  used_at    timestamptz,
  created_at timestamptz not null default now()
);
create index on password_resets (user_id);

-- =====================================================================
-- 2. Каталог
-- =====================================================================
create table categories (          -- розділи/категорії: Взуття, Одяг, ...
  id         bigint generated always as identity primary key,
  name       text not null unique,
  slug       text not null unique,
  sort_order int  not null default 0,
  created_at timestamptz not null default now()
);

create table products (
  id          bigint generated always as identity primary key,
  sku         text          not null unique default next_product_sku(),
  name        text          not null check (length(trim(name)) > 0),
  description text          not null default '',
  category_id bigint        not null references categories(id) on delete restrict,
  gender      gender_type   not null default 'unisex',
  price       numeric(12,2) not null check (price >= 0),
  old_price   numeric(12,2) check (old_price is null or old_price >= price),
  cost_price  numeric(12,2) not null default 0 check (cost_price >= 0),   -- собівартість
  icon        text          not null default 'box'
              check (icon in ('shoe','jacket','tee','pants','bag','cap','glasses','watch','dress','box')),
  hue         smallint      not null default 140 check (hue between 0 and 360),
  is_new      boolean       not null default false,                        -- «Новинки»
  new_at      timestamptz,                                                 -- порядок у новинках
  is_active   boolean       not null default true,
  created_at  timestamptz   not null default now(),
  updated_at  timestamptz   not null default now()
);
create index on products (category_id);
create index on products (gender);
create index on products (new_at desc) where is_new;
create index products_name_trgm on products using gin (name gin_trgm_ops);
create index products_sku_trgm  on products using gin (sku  gin_trgm_ops);
create trigger products_updated before update on products
  for each row execute function set_updated_at();

create table product_images (
  id         bigint generated always as identity primary key,
  product_id bigint not null references products(id) on delete cascade,
  url        text   not null,
  sort_order int    not null default 0,
  created_at timestamptz not null default now()
);
create index on product_images (product_id, sort_order);

-- Розміри = варіанти товару, з окремою наявністю та артикулом GS-0001-42
create table product_variants (
  id         bigint generated always as identity primary key,
  product_id bigint not null references products(id) on delete cascade,
  size       text   not null,
  sku        text   not null unique,
  stock      int    not null default 0 check (stock >= 0),
  unique (product_id, size)
);
create index on product_variants (product_id);

create function variant_default_sku() returns trigger language plpgsql as $$
begin
  if new.sku is null then
    select p.sku || '-' || case when new.size = 'Один розмір' then 'OS'
                                else upper(regexp_replace(new.size, '\s+', '', 'g')) end
      into new.sku from products p where p.id = new.product_id;
  end if;
  return new;
end $$;
create trigger variants_default_sku before insert on product_variants
  for each row execute function variant_default_sku();

-- Зміна артикула товару оновлює артикули всіх його розмірів
create function products_sku_cascade() returns trigger language plpgsql as $$
begin
  update product_variants set sku = new.sku || substr(sku, length(old.sku) + 1)
   where product_id = new.id;
  return new;
end $$;
create trigger products_sku_upd after update of sku on products
  for each row when (old.sku is distinct from new.sku)
  execute function products_sku_cascade();

-- Хештеги (зберігаються без #, малими літерами)
create table tags (
  id   bigint generated always as identity primary key,
  name text not null unique check (name = lower(name) and name !~ '[#\s]')
);
create table product_tags (
  product_id bigint not null references products(id) on delete cascade,
  tag_id     bigint not null references tags(id)     on delete cascade,
  primary key (product_id, tag_id)
);
create index on product_tags (tag_id);

-- =====================================================================
-- 3. Промокоди
-- =====================================================================
create table promo_codes (
  id               bigint generated always as identity primary key,
  code             text          not null unique check (code ~ '^[A-Z0-9_-]+$'),
  discount_type    discount_type not null,
  value            numeric(12,2) not null check (value > 0),
  min_order_amount numeric(12,2) not null default 0 check (min_order_amount >= 0),
  max_uses         int check (max_uses is null or max_uses > 0),           -- null = без ліміту
  used_count       int           not null default 0 check (used_count >= 0),
  expires_at       date,                                                   -- діє включно по цю дату
  is_active        boolean       not null default true,
  created_at       timestamptz   not null default now(),
  check (discount_type <> 'percent' or value <= 100)
);

-- Перевірка промокоду (ті самі правила й повідомлення, що на сайті)
create function promo_check(p_code text, p_subtotal numeric)
returns table (promo_id bigint, discount numeric, error text)
language plpgsql stable as $$
declare p promo_codes%rowtype;
begin
  select * into p from promo_codes where code = upper(trim(p_code));
  if not found then
    return query select null::bigint, 0::numeric, 'Промокод не знайдено'::text;
  elsif not p.is_active then
    return query select p.id, 0::numeric, 'Промокод вимкнено'::text;
  elsif p.expires_at is not null and p.expires_at < current_date then
    return query select p.id, 0::numeric, 'Термін дії промокоду минув'::text;
  elsif p.max_uses is not null and p.used_count >= p.max_uses then
    return query select p.id, 0::numeric, 'Ліміт використань вичерпано'::text;
  elsif p_subtotal < p.min_order_amount then
    return query select p.id, 0::numeric, ('Мінімальна сума замовлення ' || p.min_order_amount || ' ₴')::text;
  else
    return query select p.id,
      least(p_subtotal, case p.discount_type when 'percent' then round(p_subtotal * p.value / 100) else p.value end),
      null::text;
  end if;
end $$;

-- =====================================================================
-- 4. Замовлення
-- =====================================================================
create table orders (
  id              bigint generated by default as identity (start with 1001) primary key,
  user_id         bigint references users(id) on delete set null,   -- null = гостьове замовлення
  customer_name   text            not null,
  phone           text            not null,
  delivery_city   text            not null,
  delivery_branch text            not null,                          -- відділення або адреса
  shipping        shipping_method not null default 'nova_poshta',
  payment         payment_method  not null default 'cod',
  status          order_status    not null default 'new',
  promo_code_id   bigint references promo_codes(id) on delete set null,
  promo_code      text,                                              -- знімок коду
  subtotal        numeric(12,2)   not null check (subtotal >= 0),
  discount        numeric(12,2)   not null default 0 check (discount >= 0),
  total           numeric(12,2)   not null,
  created_at      timestamptz     not null default now(),
  updated_at      timestamptz     not null default now(),
  check (discount <= subtotal),
  check (total = subtotal - discount),
  check (promo_code_id is not null or discount = 0)
);
create index on orders (user_id, created_at desc);
create index on orders (status);
create index on orders (created_at);
create trigger orders_updated before update on orders
  for each row execute function set_updated_at();

create table order_items (
  id           bigint generated always as identity primary key,
  order_id     bigint        not null references orders(id) on delete cascade,
  variant_id   bigint        references product_variants(id) on delete set null,
  product_name text          not null,       -- знімки на момент покупки
  sku          text          not null,
  size         text          not null,
  quantity     int           not null check (quantity > 0),
  unit_price   numeric(12,2) not null check (unit_price >= 0),
  unit_cost    numeric(12,2) not null default 0 check (unit_cost >= 0),
  unique (order_id, variant_id)
);
create index on order_items (order_id);

-- Рух залишків (склад)
create table stock_movements (
  id         bigint generated always as identity primary key,
  variant_id bigint       not null references product_variants(id) on delete cascade,
  delta      int          not null check (delta <> 0),
  reason     stock_reason not null,
  order_id   bigint       references orders(id) on delete set null,
  note       text,
  created_by bigint       references users(id) on delete set null,
  created_at timestamptz  not null default now()
);
create index on stock_movements (variant_id, created_at desc);

-- Перед створенням замовлення: перевірити й «спалити» промокод (безпечно при гонках)
create function orders_apply_promo() returns trigger language plpgsql as $$
declare c record;
begin
  if new.promo_code_id is not null then
    select * into c from promo_check((select code from promo_codes where id = new.promo_code_id), new.subtotal);
    if c.error is not null then raise exception '%', c.error; end if;
    if new.discount <> c.discount then
      raise exception 'Невірна сума знижки: очікувалось %', c.discount;
    end if;
    update promo_codes set used_count = used_count + 1
     where id = new.promo_code_id and (max_uses is null or used_count < max_uses);
    if not found then raise exception 'Ліміт використань вичерпано'; end if;
    new.promo_code := (select code from promo_codes where id = new.promo_code_id);
  end if;
  return new;
end $$;
create trigger orders_before_insert before insert on orders
  for each row execute function orders_apply_promo();

-- Після додавання позиції: списати залишок (CHECK stock >= 0 не дасть піти в мінус)
create function order_items_stock() returns trigger language plpgsql as $$
begin
  if new.variant_id is not null then
    update product_variants set stock = stock - new.quantity where id = new.variant_id;
    insert into stock_movements (variant_id, delta, reason, order_id)
    values (new.variant_id, -new.quantity, 'order', new.order_id);
  end if;
  return null;
end $$;
create trigger order_items_after_insert after insert on order_items
  for each row execute function order_items_stock();

-- Скасування замовлення повертає товар на склад, відновлення — списує знову
create function orders_status_stock() returns trigger language plpgsql as $$
begin
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    update product_variants v set stock = v.stock + oi.quantity
      from order_items oi where oi.order_id = new.id and oi.variant_id = v.id;
    insert into stock_movements (variant_id, delta, reason, order_id)
      select variant_id, quantity, 'order_cancelled', new.id
        from order_items where order_id = new.id and variant_id is not null;
  elsif old.status = 'cancelled' and new.status <> 'cancelled' then
    update product_variants v set stock = v.stock - oi.quantity
      from order_items oi where oi.order_id = new.id and oi.variant_id = v.id;
    insert into stock_movements (variant_id, delta, reason, order_id)
      select variant_id, -quantity, 'order', new.id
        from order_items where order_id = new.id and variant_id is not null;
  end if;
  return null;
end $$;
create trigger orders_after_status after update of status on orders
  for each row when (old.status is distinct from new.status)
  execute function orders_status_stock();

-- Ручна зміна залишку (прихід товару, інвентаризація) з записом у журнал
create function adjust_stock(p_variant bigint, p_delta int,
                             p_reason stock_reason default 'manual',
                             p_note text default null, p_user bigint default null)
returns int language plpgsql as $$
declare s int;
begin
  update product_variants set stock = stock + p_delta where id = p_variant returning stock into s;
  if not found then raise exception 'Розмір не знайдено'; end if;
  insert into stock_movements (variant_id, delta, reason, note, created_by)
  values (p_variant, p_delta, p_reason, p_note, p_user);
  return s;
end $$;

-- Кошик залогіненого користувача
create table cart_items (
  user_id    bigint not null references users(id) on delete cascade,
  variant_id bigint not null references product_variants(id) on delete cascade,
  quantity   int    not null check (quantity > 0),
  added_at   timestamptz not null default now(),
  primary key (user_id, variant_id)
);

-- =====================================================================
-- 5. Контент: банер, новини
-- =====================================================================
create table banners (
  id          bigint generated always as identity primary key,
  title       text not null default '',
  subtitle    text not null default '',
  button_text text not null default '',
  category_id bigint references categories(id) on delete set null,   -- куди веде кнопка
  image_url   text,                                                  -- null = стандартний слайд
  background  text not null default '#00d45f',                       -- CSS-фон стандартного слайда
  text_color  text not null default '#0a0a0a',
  icon        text not null default 'box',
  sort_order  int  not null default 0,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

create table news_posts (
  id           bigint generated always as identity primary key,
  title        text not null,
  body         text not null,
  author_id    bigint references users(id) on delete set null,
  is_published boolean not null default true,
  published_at timestamptz not null default now()
);
create index on news_posts (published_at desc) where is_published;

-- Що вже бачив залогінений користувач (лічильник дзвіночка)
create table user_news_state (
  user_id      bigint primary key references users(id) on delete cascade,
  last_seen_at timestamptz not null default now()
);

-- =====================================================================
-- 6. Розсилки та звернення
-- =====================================================================
create table newsletter_subscribers (
  id                bigint generated always as identity primary key,
  email             citext            not null unique,
  user_id           bigint references users(id) on delete set null,
  source            subscriber_source not null default 'site',
  subscribed_at     timestamptz       not null default now(),
  unsubscribed_at   timestamptz,
  unsubscribe_token uuid              not null default gen_random_uuid() unique
);

create table newsletters (
  id               bigint generated always as identity primary key,
  subject          text not null,
  body             text not null,
  created_by       bigint references users(id) on delete set null,
  created_at       timestamptz not null default now(),
  sent_at          timestamptz,
  recipients_count int not null default 0
);

create table newsletter_deliveries (
  newsletter_id bigint not null references newsletters(id) on delete cascade,
  subscriber_id bigint not null references newsletter_subscribers(id) on delete cascade,
  status        delivery_status not null default 'pending',
  sent_at       timestamptz,
  error         text,
  primary key (newsletter_id, subscriber_id)
);

create table feedback_messages (
  id         bigint generated always as identity primary key,
  user_id    bigint references users(id) on delete set null,
  name       text   not null,
  email      citext not null,
  message    text   not null,
  status     feedback_status not null default 'new',
  created_at timestamptz     not null default now()
);
create index on feedback_messages (status, created_at desc);

-- =====================================================================
-- 7. Бухгалтерський облік
-- =====================================================================
create table expense_categories (
  id   bigint generated always as identity primary key,
  name text not null unique
);

create table expenses (
  id           bigint generated always as identity primary key,
  expense_date date          not null default current_date,
  category_id  bigint        not null references expense_categories(id) on delete restrict,
  amount       numeric(12,2) not null check (amount > 0),
  note         text          not null default '',
  created_by   bigint references users(id) on delete set null,
  created_at   timestamptz   not null default now()
);
create index on expenses (expense_date);

-- Налаштування магазину (контакти, соцмережі, поріг безкоштовної доставки)
create table store_settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);

-- Сторінки футера (Про Grapp, Угода, Політика, Доставка тощо) — редагуються в адмінці.
-- У тексті можна використовувати {{free_from}} — сума безкоштовної доставки з налаштувань.
create table site_pages (
  slug       text primary key,
  title      text not null,
  body       text not null,
  sort_order int  not null default 0,
  updated_at timestamptz not null default now()
);

-- =====================================================================
-- 8. Представлення для сайту й адмінки
-- =====================================================================
-- Каталог: товар + розділ + залишок + хештеги + головне фото + текст для пошуку
create view v_product_catalog as
select p.id, p.sku, p.name, p.description, p.price, p.old_price, p.icon, p.hue, p.gender,
       p.is_new, p.new_at, p.created_at,
       c.id   as category_id,
       c.name as category,
       coalesce((select sum(v.stock) from product_variants v where v.product_id = p.id), 0)::int as total_stock,
       coalesce((select array_agg(t.name order by t.name)
                   from product_tags pt join tags t on t.id = pt.tag_id
                  where pt.product_id = p.id), '{}'::text[]) as tags,
       (select i.url from product_images i where i.product_id = p.id order by i.sort_order, i.id limit 1) as main_image,
       lower(p.name || ' ' || p.sku || ' ' || c.name || ' ' ||
             case p.gender when 'women' then 'жіноче жінкам жінка'
                           when 'men'   then 'чоловіче чоловікам чоловік'
                           else 'унісекс' end || ' ' ||
             coalesce((select string_agg(t.name, ' ')
                         from product_tags pt join tags t on t.id = pt.tag_id
                        where pt.product_id = p.id), '')) as search_text
  from products p
  join categories c on c.id = p.category_id
 where p.is_active;

-- Пошук: назва, артикул, хештег, розділ, категорія (усі слова мають збігатися)
create function search_products(p_query text) returns setof v_product_catalog
language sql stable as $$
  select c.* from v_product_catalog c
   where not exists (
     select 1 from unnest(regexp_split_to_array(lower(trim(coalesce(p_query, ''))), '\s+')) as t
      where t <> '' and position(regexp_replace(t, '^#', '') in c.search_text) = 0)
$$;

-- Фінанси кожного замовлення: виручка, собівартість, валовий прибуток
create view v_order_financials as
select o.id as order_id, o.created_at, o.status, o.total as revenue,
       coalesce(sum(oi.unit_cost * oi.quantity), 0)           as cogs,
       o.total - coalesce(sum(oi.unit_cost * oi.quantity), 0) as gross_profit
  from orders o left join order_items oi on oi.order_id = o.id
 group by o.id;

-- Журнал операцій: доходи (крім скасованих) і витрати
create view v_accounting_ledger as
select (o.created_at at time zone 'Europe/Kyiv')::date as op_date,
       'income'::text as op_type,
       ('Замовлення №' || o.id)::text as description,
       o.total as amount,
       o.id as order_id, null::bigint as expense_id
  from orders o where o.status <> 'cancelled'
union all
select e.expense_date, 'expense'::text,
       (ec.name || coalesce(': ' || nullif(e.note, ''), ''))::text,
       -e.amount, null::bigint, e.id
  from expenses e join expense_categories ec on ec.id = e.category_id;

-- Підсумки по місяцях
create view v_monthly_summary as
with inc as (
  select date_trunc('month', f.created_at at time zone 'Europe/Kyiv')::date as m,
         count(*) as orders, sum(f.revenue) as revenue, sum(f.cogs) as cogs
    from v_order_financials f where f.status <> 'cancelled' group by 1),
exps as (
  select date_trunc('month', expense_date)::date as m, sum(amount) as expenses
    from expenses group by 1)
select coalesce(i.m, e.m)                                   as month,
       coalesce(i.orders, 0)                                as orders,
       coalesce(i.revenue, 0)                               as revenue,
       coalesce(i.cogs, 0)                                  as cogs,
       coalesce(i.revenue, 0) - coalesce(i.cogs, 0)         as gross_profit,
       coalesce(e.expenses, 0)                              as expenses,
       coalesce(i.revenue, 0) - coalesce(i.cogs, 0) - coalesce(e.expenses, 0) as net_profit
  from inc i full join exps e on e.m = i.m
 order by 1 desc;

-- Вартість залишків на складі
create view v_inventory_value as
select p.id as product_id, p.sku, p.name,
       coalesce(sum(v.stock), 0)               as qty,
       coalesce(sum(v.stock), 0) * p.cost_price as value_at_cost,
       coalesce(sum(v.stock), 0) * p.price      as value_at_retail
  from products p left join product_variants v on v.product_id = p.id
 group by p.id;

-- Права для застосунку (виконайте під суперкористувачем, змінивши пароль)
-- create role grappshopp_app login password 'CHANGE_ME';
-- grant select, insert, update, delete on all tables in schema public to grappshopp_app;
-- grant usage, select on all sequences in schema public to grappshopp_app;
-- grant execute on all functions in schema public to grappshopp_app;

commit;
